export { default } from './connect-wallet.container'
