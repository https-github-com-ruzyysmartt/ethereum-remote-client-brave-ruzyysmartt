const Routes = require('../../../../../ui/app/helpers/constants/routes')

Routes.INITIALIZE_SELECT_ACTION_ROUTE = Routes.INITIALIZE_WELCOME_ROUTE

module.exports = Routes
