import AdvancedTab from '../../../../../../ui/app/pages/settings/advanced-tab/advanced-tab.component'

module.exports = class BraveAdvancedTab extends AdvancedTab {

  renderMobileSync () {
    return null
  }

  renderThreeBoxControl () {
    return null
  }
}
