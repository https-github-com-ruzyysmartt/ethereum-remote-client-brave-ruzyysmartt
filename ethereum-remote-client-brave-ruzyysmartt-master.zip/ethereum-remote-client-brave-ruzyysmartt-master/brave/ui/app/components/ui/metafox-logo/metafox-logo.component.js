import MetaFoxLogo from '../../../../../../ui/app/components/ui/metafox-logo/metafox-logo.component'

module.exports = class BraveMetaFoxLogo extends MetaFoxLogo {

  render () {
    return null
  }
}
