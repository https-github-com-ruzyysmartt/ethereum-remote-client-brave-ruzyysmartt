#!/usr/bin/env bash
set -x

mkdir -p build-artifacts/yarn-install-har
mv ./*.har build-artifacts/yarn-install-har/
