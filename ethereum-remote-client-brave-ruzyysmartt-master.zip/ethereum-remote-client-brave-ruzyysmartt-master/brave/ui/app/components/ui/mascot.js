import { PureComponent } from 'react'

export default class BraveMascot extends PureComponent {
  render () {
    return null
  }
}
