const ThreeBoxController = require('../../../../app/scripts/controllers/threebox')

class BraveThreeBoxController extends ThreeBoxController {

  async init () {
    /* no-op */
  }
}

module.exports = BraveThreeBoxController
