export default {
  '0x0D8775F648430679A709E98d2b0Cb6250d2887EF': {
    'name': 'Basic Attention Token',
    'logo': 'BAT_icon.svg',
    'erc20': true,
    'symbol': 'BAT',
    'decimals': 18,
    'address': '0x0D8775F648430679A709E98d2b0Cb6250d2887EF',
  },
}
