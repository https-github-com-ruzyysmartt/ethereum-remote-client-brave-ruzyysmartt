module.exports = {
  'ledger': 'https://shop.ledger.com/?r=0ba5d7199327',
  'trezor': 'https://shop.trezor.io/product/trezor-one-metallic?offer_id=24&aff_id=3494',
}
