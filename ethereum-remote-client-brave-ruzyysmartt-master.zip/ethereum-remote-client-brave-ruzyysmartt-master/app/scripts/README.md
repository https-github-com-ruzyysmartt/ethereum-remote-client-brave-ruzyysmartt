# Main MetaMask Code

This folder contains the core-code.

Currently, it is organized mostly based on file category, like:

controllers, migrations, lib

## Ongoing Task 

Refactor code-structure, thus the subsystems are reflected on the filesystem.

### Examples

