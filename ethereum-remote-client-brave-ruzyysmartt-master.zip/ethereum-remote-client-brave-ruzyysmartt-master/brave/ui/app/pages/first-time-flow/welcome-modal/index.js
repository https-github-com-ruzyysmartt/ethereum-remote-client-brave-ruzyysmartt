export { default } from './welcome-modal.container'
